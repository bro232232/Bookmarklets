javascript: alert("Use at your own risk."); while (true){window.open("https://www.google.com")}
