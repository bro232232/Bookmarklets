javascript:Array.prototype.slice.call(document.querySelectorAll("input[type='password']")).map(function(el){el.setAttribute('type','text')})
