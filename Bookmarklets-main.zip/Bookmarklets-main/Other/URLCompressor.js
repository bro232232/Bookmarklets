javascript:void(open('http://tinyurl.com/create.php?url=%27+encodeURIComponent(location.href)))
